package com.test;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

/*@Aspect*/
public class AccountAspect {

	/*@AfterThrowing("advicetoAll")*/
	public void beforeAdvice()
	{
		System.out.println("After throwing exception advice");
	}
	
	/*
	@Around("adviceToAll")
	public Object beforeAdvice(ProceedingJoinPoint pjp) throws Throwable
	{
		System.out.println("Before Advice called");
		long start=System.currentTimeMillis();
		Object obj=pjp.proceed();
		int amt=(Integer)obj;
	System.out.println("After Withdraw Amount="+amt);
	return(obj);	
	long stop=System.currentTimeMillis();
		System.out.println(" After Advice Called");
		System.out.println("Time="+(stop-start));
	}*/
	
	/*@After("execution(public void com.test.*.withdraw())")
	public void afterAdvice()
	{
		System.out.println("After Advice called");
	}
	*/
	/*@Pointcut("execution (* com.test.*.withdraw(..))")
	public void adviceToAll()
	{
		
	}*/
}
