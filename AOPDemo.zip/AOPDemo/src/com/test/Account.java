package com.test;

public class Account {

	public void withdraw()
	{
		/*if(amt==0)
			throw new ArithmeticException("AMOUNT ZERO ");
		return amt;*/
	System.out.println("Withdraw Called");
	}
}
