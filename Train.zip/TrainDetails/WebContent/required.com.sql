

INSERT INTO TrainDetails VALUES ('S10001','12-Dec-2017','Mumbai',457,12,'Rajadhani');

INSERT INTO TrainDetails VALUES ('S10002','18-Jan-2017','Vadodara',500,32,'Shatabdi');

INSERT INTO TrainDetails VALUES ('S10003','08-Mar-2017','Bangalore',650,20,'Yeswantpur Exp');

INSERT INTO TrainDetails VALUES ('S10004','30-Jul-2017','Pune',350,8,'Pune Express');

INSERT INTO TrainDetails VALUES ('S10005','27-Oct-2017','Chennai',625,0,'Chennai Express');