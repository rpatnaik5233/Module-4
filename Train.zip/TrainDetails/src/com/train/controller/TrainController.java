package com.train.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.train.bean.TrainBean;
import com.train.exception.TrainException;
import com.train.service.ITrainService;

@Controller
public class TrainController {

	@Autowired
	private ITrainService trainService;

	public ITrainService getTrainService() {
		return trainService;
	}

	public void setTrainService(ITrainService trainService) {
		this.trainService = trainService;
	}

	@RequestMapping("/showHome")
	public String showHomePage() {
		return ("index");
	}

	@RequestMapping("viewAllTrains")
	public ModelAndView showAllTrains(@ModelAttribute("train") TrainBean bean) {
		ModelAndView model = new ModelAndView();
		try {
			List<TrainBean> list = trainService.viewAllTrains();
			model.setViewName("view");
			model.addObject("list", list);
		} catch (TrainException e) {
			model.setViewName("error");
			model.addObject("message", e.getMessage());
		}
		return model;

	}

	@RequestMapping("retrieveTrainDetail")
	public ModelAndView retrieveTrainDetail(@RequestParam("id") String trainId) {

		ModelAndView model = new ModelAndView();
		TrainBean trainBean;
		try {
			trainBean = trainService.retrieveDetail(trainId);
			model.setViewName("viewTrain");
			model.addObject("trainBean", trainBean);
		} catch (TrainException e) {
			model.setViewName("error");
			model.addObject("message", e.getMessage());
		}
		return model;

	}

	@RequestMapping("book")
	public ModelAndView bookTrain(@RequestParam("id") String trainId,
			@RequestParam("seats") int seats,
			@RequestParam("enteredSeats") int enteredSeats) {

		ModelAndView model = new ModelAndView();
		boolean isUpdated = false;
		double amount = 0;
		TrainBean trainBean;
		TrainBean trainBeanDetails = new TrainBean();
		try {

			trainBean = trainService.retrieveDetail(trainId);
			if (seats - enteredSeats >= 0) {
				amount = enteredSeats * trainBean.getFare();
				trainBeanDetails.setFare(amount);
				trainBean.setSeats(seats - enteredSeats);
				isUpdated = trainService.updateSeats(trainBean);
				model.setViewName("bookTrain");
				model.addObject("trainBean", trainBean);
				model.addObject("trainBeanDetails", trainBeanDetails);

			}else{
				model.setViewName("error");
				model.addObject("message", "Only " + seats + " are available for this train");
			}
		} catch (TrainException e) {
			model.setViewName("error");
			model.addObject("message", e.getMessage());
		}
		return model;

	}

	@RequestMapping("bookDetails")
	public ModelAndView bookDetails(@RequestParam("id") String trainId,
			@RequestParam("seats") int seats) {

		ModelAndView model = new ModelAndView();
		boolean isUpdated = false;
		TrainBean trainBean;
		try {
			
			trainBean = trainService.retrieveDetail(trainId);
			model.setViewName("bookDetails");
			model.addObject("trainBean", trainBean);
		} catch (TrainException e) {
			model.setViewName("error");
			model.addObject("message", e.getMessage());
		}
		return model;

	}
}
