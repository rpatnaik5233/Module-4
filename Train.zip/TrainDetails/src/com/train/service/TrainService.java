package com.train.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.train.bean.TrainBean;
import com.train.dao.ITrainDao;
import com.train.dao.TrainDao;
import com.train.exception.TrainException;

@Service
public class TrainService implements ITrainService {
	
	@Autowired
	private ITrainDao trainDao;
	
	

	public ITrainDao getTrainDao() {
		return trainDao;
	}



	public void setTrainDao(ITrainDao trainDao) {
		this.trainDao = trainDao;
	}



	@Override
	public List<TrainBean> viewAllTrains() throws TrainException {
		return trainDao.viewAllTrains();
	}



	@Override
	public TrainBean retrieveDetail(String trainId) throws TrainException {
		
		return trainDao.retrieveDetail(trainId);
	}



	@Override
	public boolean updateSeats(TrainBean trainBean) throws TrainException {
		
		return trainDao.updateSeats(trainBean);
	}

}
