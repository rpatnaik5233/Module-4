package com.train.dao;

import java.util.List;

import com.train.bean.TrainBean;
import com.train.exception.TrainException;

public interface ITrainDao {
	public List<TrainBean> viewAllTrains() throws TrainException;
	
	public TrainBean retrieveDetail(String trainId) throws TrainException;
	
	public boolean updateSeats(TrainBean trainBean) throws TrainException;

}
