CREATE TABLE Product(product_id NUMBER(5) PRIMARY KEY,product_name VARCHAR2(30),product_price NUMBER(10),product_quantity NUMBER(5), description VARCHAR2(40));

INSERT INTO Product VALUES(1001,'iPhone',45000,10,'Electronic Equipment from apple');
INSERT INTO Product VALUES(1002,'Cartoon Shirt',345,15,'Kids wear 4 to 12 Years');
INSERT INTO Product VALUES(1003,'Sofa',20000,12,'HouseHold Furnitures');