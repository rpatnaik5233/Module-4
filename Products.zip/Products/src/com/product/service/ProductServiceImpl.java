package com.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.bean.ProductBean;
import com.product.dao.IProductDao;
import com.product.exception.ProductException;
@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	IProductDao productDao;
	@Override
	public ProductBean deleteProduct(int productId) throws ProductException {
		
		return productDao.deleteProduct(productId);
	}
	@Override
	public List<ProductBean> viewAllProduct() throws ProductException {
		return productDao.viewAllProduct();
	}

}
