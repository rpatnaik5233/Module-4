package com.product.service;

import java.util.List;

import com.product.bean.ProductBean;
import com.product.exception.ProductException;

public interface IProductService {
	public List<ProductBean> viewAllProduct() throws ProductException;
	public ProductBean deleteProduct(int productId) throws ProductException;
}
