package com.product.exception;

public class ProductException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3069260031055529762L;

	public ProductException() {
		super();
	}

	public ProductException(String arg0) {
		super(arg0);
	}

}
