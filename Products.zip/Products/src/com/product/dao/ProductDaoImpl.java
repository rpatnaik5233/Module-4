package com.product.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.product.bean.ProductBean;
import com.product.exception.ProductException;
@Repository
@Transactional
public class ProductDaoImpl implements IProductDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<ProductBean> viewAllProduct() throws ProductException {
		List<ProductBean> list = new ArrayList<ProductBean>();
		try {
			TypedQuery<ProductBean> query=entityManager.createQuery("From ProductBean",ProductBean.class);
			list = query.getResultList();
		} catch (Exception e) {
			
			throw new ProductException("Unable to fetch Products");
		}
		return list;
	}
	
	@Override
	public ProductBean deleteProduct(int productId) throws ProductException {
		ProductBean bean= new ProductBean();
		bean=entityManager.find(ProductBean.class, productId);
		if(bean==null)
		{
			System.out.println("Record not found");
		}
		else{
			entityManager.remove(bean);
		}
		return bean;
	}
	

}
