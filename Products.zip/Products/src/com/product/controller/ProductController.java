package com.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.product.bean.ProductBean;
import com.product.exception.ProductException;
import com.product.service.IProductService;


@Controller
public class ProductController {

	@Autowired
	IProductService productService;
	
	@RequestMapping("/showHome")
	public String showHomePage()
	{
		return("index");
	}
	
	
	@RequestMapping("showAll")
	public ModelAndView showAllEmployees() {
		ModelAndView mv = new ModelAndView();
		try {
			List<ProductBean> list = productService.viewAllProduct();
			mv.setViewName("index");
			mv.addObject("list", list);
		} catch (ProductException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}

		return mv;
	}
	
	@RequestMapping("/deleteproduct")
	public ModelAndView deleteProduct(@ModelAttribute("product") ProductBean bean,@RequestParam("productId") int productId) throws ProductException
	{
		ModelAndView mv= new ModelAndView();
		try
		{
			bean=productService.deleteProduct(productId);
			mv.addObject("product", bean);
			
			List<ProductBean> list = productService.viewAllProduct();
			mv.setViewName("index");
			mv.addObject("list", list);
		}
		catch(Exception e)
		{
			mv.addObject("message", e.getMessage());
			mv.setViewName("error");
		}
		return mv;
	}
}
