package com.cg.author.dao;

import java.util.List;

import javax.naming.AuthenticationException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.author.entities.Author;

public class AuthorDAOImpl implements IAuthorDAO {
	private EntityManager entityManager;
	Author author = new Author();

	@Override
	public void addAuthor(Author author) throws AuthenticationException {
		entityManager.persist(author);
	}

	@Override
	public Author deleteAuthor(int authorId) throws AuthenticationException {
		author = entityManager.find(Author.class, authorId);
		return author;
	}

	@Override
	public Author findAuthor(int authorId) throws AuthenticationException {
		author = entityManager.find(Author.class, authorId);
		return author;
	}

	@Override
	public List<Author> viewAll(Author author) throws AuthenticationException {
		TypedQuery<Author> qry = entityManager.createQuery("from Author",
				Author.class);
		List<Author> list = qry.getResultList();
		for (Author author2 : list) {
			System.out.println(author2.getAuthorId() + " " + author2.getFname()
					+ " " + author2.getMname() + " " + author2.getLname() + " "
					+ author2.getPhoneNo());
		}
		return list;
	}

	@Override
	public void commitTransaction() {

		entityManager.getTransaction().commit();
	}

	@Override
	public void beginTransaction() {
		EntityManagerFactory entityManagerFactory = Persistence
				.createEntityManagerFactory("JPA-PU");
		entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

	}

}
