package com.cg.author.dao;

import java.util.List;

import javax.naming.AuthenticationException;

import com.cg.author.entities.Author;

public interface IAuthorDAO {

	public void addAuthor(Author author) throws AuthenticationException;
	public Author deleteAuthor(int authorId) throws AuthenticationException;
	public Author findAuthor(int authorId) throws AuthenticationException;
	List<Author> viewAll(Author author) throws AuthenticationException;
	public void commitTransaction();
	public void beginTransaction();
}
