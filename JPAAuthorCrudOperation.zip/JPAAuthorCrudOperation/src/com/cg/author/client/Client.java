package com.cg.author.client;

import java.util.List;
import java.util.Scanner;

import javax.naming.AuthenticationException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.author.entities.Author;
import com.cg.author.service.AuthorServiceImpl;
import com.cg.author.service.IAuthorService;

public class Client {

	public static void main(String[] args) {
		IAuthorService authorservice=new AuthorServiceImpl();
		Author author=new Author();
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		boolean isInserted=true;
		while(isInserted)
		{
			System.out.println("Enter your choice:-");
			System.out.println("1. Add Author.");
			System.out.println("2. Delete Author.");
			System.out.println("3. Find Author.");
			System.out.println("4. Display all Authors.");
			System.out.println("5. Exit");
			int choice;
			Scanner scInput=new Scanner(System.in);
		choice=scInput.nextInt();
		scInput.nextLine();
		switch(choice)
		{
		case 1:
			System.out.println("Enter Author Details:");
			System.out.println("First Name:");
			String fname=scInput.nextLine();
			System.out.println("Middle Name:");
			String mname=scInput.nextLine();
			System.out.println("Last Name:");
			String lname=scInput.nextLine();
			System.out.println("Phone No:");
			int phoneno=scInput.nextInt();
			author.setFname(fname);
			author.setMname(mname);
			author.setLname(lname);
			author.setPhoneNo(phoneno);
			
			try {
				int authorId=authorservice.addAuthor(author);
				System.out.println("The Author Id is:"+authorId);
			} catch (AuthenticationException e) {
						e.getMessage();
			}
			
			break;
		case 2:
			System.out.println("Enter the Auther Id which you want to delete:");
			int id=scInput.nextInt();
			try {
				author=entityManager.find(Author.class, id);
				if(author==null)
				{
					System.out.println("Author not Found!!");
				}
				else
				{
					System.out.println(author.getAuthorId()+" "+author.getFname()+" "+author.getMname()+" "+author.getLname()+" "+author.getPhoneNo());
					author=authorservice.deleteAuthor(id);
					System.out.println("Author Deleted successfully");
				}
				
				
			} catch (AuthenticationException e) {
					e.printStackTrace();
			}
			break;
		case 3:
			System.out.println("Enter the Auther Id which you want to find:");
			 id=scInput.nextInt();
				author=entityManager.find(Author.class, id);
				if(author==null)
				{
					System.out.println("Author not Found!!");
				}
				else
				{
					System.out.println(author.getAuthorId()+" "+author.getFname()+" "+author.getMname()+" "+author.getLname()+" "+author.getPhoneNo());
					System.out.println("Author Found successfully");
				}
			
			break;
		case 4:
			Query qry=entityManager.createQuery("from Author");
			List<Author> list=qry.getResultList();
			for (Author author2 : list) {
				System.out.println(author2.getAuthorId()+" "+author2.getFname()+" "+author2.getMname()+" "+author2.getLname()+" "+author2.getPhoneNo());
			}
			
			break;
		case 5:
			isInserted=false;
			break;
			default:
				System.out.println("Wrong Choice");
				break;
		}
	}
	}

}
