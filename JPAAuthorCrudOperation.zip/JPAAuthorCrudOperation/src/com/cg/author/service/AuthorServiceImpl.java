package com.cg.author.service;

import java.util.List;

import javax.naming.AuthenticationException;


import com.cg.author.dao.AuthorDAOImpl;
import com.cg.author.entities.Author;

public class AuthorServiceImpl implements IAuthorService {

	private AuthorDAOImpl authorDAO;
	Author author=new Author();
	
	
	public AuthorServiceImpl() {
		authorDAO=new AuthorDAOImpl();
	}

	@Override
	public int addAuthor(Author author) throws AuthenticationException {

		authorDAO.beginTransaction();
		authorDAO.addAuthor(author);
		authorDAO.commitTransaction();
		return author.getAuthorId();
	}

	@Override
	public Author deleteAuthor(int authorId) throws AuthenticationException {
		authorDAO.beginTransaction();
		authorDAO.deleteAuthor(author.getAuthorId());
		authorDAO.commitTransaction();
		return author;
	}

	@Override
	public Author findAuthor(int authorId) throws AuthenticationException {
				authorDAO.findAuthor(author.getAuthorId());
				return author;
	}

	@Override
	public List<Author> viewAll(Author author) throws AuthenticationException {
		authorDAO.beginTransaction();
		List<Author> list=authorDAO.viewAll(author);
		authorDAO.commitTransaction();
		return list;
	}

}
