package com.cg.author.service;

import java.util.List;

import javax.naming.AuthenticationException;

import com.cg.author.entities.Author;

public interface IAuthorService {
	public int addAuthor(Author author) throws AuthenticationException;
	public Author deleteAuthor(int authorId) throws AuthenticationException;
	public Author findAuthor(int authorId) throws AuthenticationException;
	List<Author> viewAll(Author author) throws AuthenticationException;
}
