package com.cg.author.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Author_tbl")
public class Author {
	@Id
	@GeneratedValue
	@Column(name="id")
	private int authorId;
	@Column(name="fname",length=20)
	private String fname;
	@Column(name="mname",length=20)
	private String mname;
	@Column(name="lname",length=20)
	private String lname;
	@Column(name="phone_no")
	private int phoneNo;
	
	public Author() {
		super();
	}

	public Author(int authorId, String fname, String mname, String lname,
			int phoneNo) {
		super();
		this.authorId = authorId;
		this.fname = fname;
		this.mname = mname;
		this.lname = lname;
		this.phoneNo = phoneNo;
	}

	public int getAuthorId() {
		return authorId;
	}

	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public int getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	
	
}
